#include <unistd.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <sys/ioctl.h>
main() { int x = TIOCGWINSZ; }
