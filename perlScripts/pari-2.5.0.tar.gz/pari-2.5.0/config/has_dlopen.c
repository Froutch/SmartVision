#include <stdio.h>
#include <dlfcn.h>
main() {dlopen("a",RTLD_LAZY);}
