#include <readline/readline.h>
main() { char *s = readline("?"); }
