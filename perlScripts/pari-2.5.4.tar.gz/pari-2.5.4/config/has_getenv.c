#include <stdlib.h>
main(){ (void)getenv(""); }
